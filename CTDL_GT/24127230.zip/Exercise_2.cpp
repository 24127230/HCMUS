#include <fstream>
#include <iostream>
using namespace std;

bool readMatrix(const char *filename, int **&matrix, int &rows, int &cols);
void printMatrix(const char *filename, int **matrix, int rows, int cols);
bool multiplyMatrices(int **a, int aRows, int aCols,
                      int **b, int bRows, int bCols,
                      int **&res, int &resRows, int &resCols);
void transposeMatrix(int **matrix, int rows, int cols,
                     int **&res, int &resRows, int &resCols);

bool readMatrix(const char *filename, int **&matrix, int &rows, int &cols)
{
    ifstream fin(filename);
    if (!fin.is_open())
    {
        cout << "Can not open file " << filename << " to read!";
        return false;
    }
    matrix = new int *[rows];
    for (int i = 0; i < rows; i++)
    {
        matrix[i] = new int[cols];
        for (int j = 0; j < cols; j++)
        {
            matrix[i][j] = ;
        }
    }
    return true;
}
void printMatrix(const char *filename, int **matrix, int rows, int cols)
{
    ofstream fout(filename);
    if (!fout.is_open())
    {
        cout << "Can not open file " << filename << " to write!";
        return;
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            fout << matrix[i][j] << " ";
        }
        cout << '\n';
    }
}
bool multiplyMatrices(int **a, int aRows, int aCols,
                      int **b, int bRows, int bCols,
                      int **&res, int &resRows, int &resCols)
{
    if (aCols != bRows)
    {
        cout << "Can not multiply these matrices!";
        return false;
    }
    resRows = aRows;
    resCols = bCols;
    res = new int *[resRows];
    for (int i = 0; i < resRows; i++)
    {
        for (int j = 0; j < resCols; j++)
        {
            for (int z = 0; z < aCols; z++)
            {
                res[i][j] += a[i][z] * b[z][j];
            }
        }
    }
    return true;
}